<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
$currentPage = $_SERVER["PHP_SELF"];

$maxRows_quoteList = 20;
$pageNum_quoteList = 0;
if (isset($_GET['pageNum_quoteList'])) {
  $pageNum_quoteList = $_GET['pageNum_quoteList'];
}
$startRow_quoteList = $pageNum_quoteList * $maxRows_quoteList;

mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_quoteList = "SELECT quotations.quote_id, quotations.quotation, authors.first_name, authors.family_name FROM quotations, authors WHERE quotations.author_id = authors.author_id ORDER BY authors.family_name, authors.first_name, quotations.quotation";
$query_limit_quoteList = sprintf("%s LIMIT %d, %d", $query_quoteList, $startRow_quoteList, $maxRows_quoteList);
$quoteList = mysql_query($query_limit_quoteList, $seasonAdmin) or die(mysql_error());
$row_quoteList = mysql_fetch_assoc($quoteList);

if (isset($_GET['totalRows_quoteList'])) {
  $totalRows_quoteList = $_GET['totalRows_quoteList'];
} else {
  $all_quoteList = mysql_query($query_quoteList);
  $totalRows_quoteList = mysql_num_rows($all_quoteList);
}
$totalPages_quoteList = ceil($totalRows_quoteList/$maxRows_quoteList)-1;

$queryString_quoteList = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_quoteList") == false && 
        stristr($param, "totalRows_quoteList") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_quoteList = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_quoteList = sprintf("&totalRows_quoteList=%d%s", $totalRows_quoteList, $queryString_quoteList);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>List all quotations</title>
<style type="text/css">
tr {vertical-align: top;}
.author {white-space: nowrap;}
table {margin-right: auto; margin-left: auto;}
</style>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Contents of quotations table</h1>
<table width="700" cellpadding="4">
  <tr>
    <th scope="col">Name</th>
    <th scope="col">Quotation</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <?php do { ?>
  <tr>
    <td><?php echo $row_quoteList['first_name']; ?> <?php echo $row_quoteList['family_name']; ?></td>
    <td><?php echo $row_quoteList['quotation']; ?></td>
    <td><a href="quote_update.php?quote_id=<?php echo $row_quoteList['quote_id']; ?>">EDIT</a></td>
    <td><a href="quote_delete.php?quote_id=<?php echo $row_quoteList['quote_id']; ?>">DELETE</a></td>
  </tr>
  <?php } while ($row_quoteList = mysql_fetch_assoc($quoteList)); ?>
</table>

<table border="0" width="50%" align="center">
  <tr>
    <td width="23%" align="center"><?php if ($pageNum_quoteList > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_quoteList=%d%s", $currentPage, 0, $queryString_quoteList); ?>"><img src="First.gif" border=0></a>
        <?php } // Show if not first page ?>
    </td>
    <td width="31%" align="center"><?php if ($pageNum_quoteList > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_quoteList=%d%s", $currentPage, max(0, $pageNum_quoteList - 1), $queryString_quoteList); ?>"><img src="Previous.gif" border=0></a>
        <?php } // Show if not first page ?>
    </td>
    <td width="23%" align="center"><?php if ($pageNum_quoteList < $totalPages_quoteList) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_quoteList=%d%s", $currentPage, min($totalPages_quoteList, $pageNum_quoteList + 1), $queryString_quoteList); ?>"><img src="Next.gif" border=0></a>
        <?php } // Show if not last page ?>
    </td>
    <td width="23%" align="center"><?php if ($pageNum_quoteList < $totalPages_quoteList) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_quoteList=%d%s", $currentPage, $totalPages_quoteList, $queryString_quoteList); ?>"><img src="Last.gif" border=0></a>
        <?php } // Show if not last page ?>
    </td>
  </tr>
</table>
<p>&nbsp; </p>
</body>
</html>
<?php
mysql_free_result($quoteList);
?>
