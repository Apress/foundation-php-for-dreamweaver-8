<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
$currentPage = $_SERVER["PHP_SELF"];

function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
$var1_checkAuthor = "Dream";
if (isset($_POST['first_name'])) {
  $var1_checkAuthor = (get_magic_quotes_gpc()) ? $_POST['first_name'] : addslashes($_POST['first_name']);
}
$var2_checkAuthor = "Weaver";
if (isset($_POST['family_name'])) {
  $var2_checkAuthor = (get_magic_quotes_gpc()) ? $_POST['family_name'] : addslashes($_POST['family_name']);
}
mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_checkAuthor = sprintf("SELECT * FROM authors WHERE authors.first_name = '%s' AND authors.family_name = '%s'", $var1_checkAuthor,$var2_checkAuthor);
$checkAuthor = mysql_query($query_checkAuthor, $seasonAdmin) or die(mysql_error());
$row_checkAuthor = mysql_fetch_assoc($checkAuthor);
$totalRows_checkAuthor = mysql_num_rows($checkAuthor);

$maxRows_listAuthors = 25;
$pageNum_listAuthors = 0;
if (isset($_GET['pageNum_listAuthors'])) {
  $pageNum_listAuthors = $_GET['pageNum_listAuthors'];
}
$startRow_listAuthors = $pageNum_listAuthors * $maxRows_listAuthors;

mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_listAuthors = "SELECT * FROM authors ORDER BY authors.family_name, authors.first_name";
$query_limit_listAuthors = sprintf("%s LIMIT %d, %d", $query_listAuthors, $startRow_listAuthors, $maxRows_listAuthors);
$listAuthors = mysql_query($query_limit_listAuthors, $seasonAdmin) or die(mysql_error());
$row_listAuthors = mysql_fetch_assoc($listAuthors);

if (isset($_GET['totalRows_listAuthors'])) {
  $totalRows_listAuthors = $_GET['totalRows_listAuthors'];
} else {
  $all_listAuthors = mysql_query($query_listAuthors);
  $totalRows_listAuthors = mysql_num_rows($all_listAuthors);
}
$totalPages_listAuthors = ceil($totalRows_listAuthors/$maxRows_listAuthors)-1;

$queryString_listAuthors = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_listAuthors") == false && 
        stristr($param, "totalRows_listAuthors") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_listAuthors = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_listAuthors = sprintf("&totalRows_listAuthors=%d%s", $totalRows_listAuthors, $queryString_listAuthors);

// assume that no match has been found
$alreadyRegistered = false;

// check whether recordset found any matches
if ($totalRows_checkAuthor > 0) {
  $alreadyRegistered  = true;
  }
else {
  // go ahead with Insert Record server behavior
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "insertAuthor")) {
  $insertSQL = sprintf("INSERT INTO authors (first_name, family_name) VALUES (%s, %s)",
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['family_name'], "text"));

  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $Result1 = mysql_query($insertSQL, $seasonAdmin) or die(mysql_error());

  $insertGoTo = "author_insert.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}
}

?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Insert new author</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Insert new author </h1>
<?php
if ($_POST && $alreadyRegistered) {
  echo '<p class="warning">'.$_POST['first_name'].' '.$_POST['family_name'].' is already registered</p>';
  }
?>
<form action="<?php echo $editFormAction; ?>" id="insertAuthor" name="insertAuthor" method="POST">
  <p>
    <label for="first_name">First name:</label>
    <br />
    <input type="text" name="first_name" id="first_name" />
  </p>
  <p>
    <label for="family_name">Family name:</label>
    <br />
    <input type="text" name="family_name" id="family_name" />
  </p>
  <p>
    <input name="insert" type="submit" id="insert" value="Insert author" />
  </p>
  
  
  <input type="hidden" name="MM_insert" value="insertAuthor">
</form>
<table width="300" cellpadding="4">
  <tr>
    <th scope="col">Name</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <?php do { ?>
    <tr>
      <td><?php echo $row_listAuthors['first_name']; ?> <?php echo $row_listAuthors['family_name']; ?></td>
      <td><a href="author_update.php?author_id=<?php echo $row_listAuthors['author_id']; ?>">EDIT</a></td>
      <td><a href="author_delete.php?author_id=<?php echo $row_listAuthors['author_id']; ?>">DELETE</a></td>
    </tr>
    <?php } while ($row_listAuthors = mysql_fetch_assoc($listAuthors)); ?>
</table>

<table border="0" width="50%" align="center">
  <tr>
    <td width="23%" align="center"><?php if ($pageNum_listAuthors > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_listAuthors=%d%s", $currentPage, 0, $queryString_listAuthors); ?>">First</a>
        <?php } // Show if not first page ?>
    </td>
    <td width="31%" align="center"><?php if ($pageNum_listAuthors > 0) { // Show if not first page ?>
        <a href="<?php printf("%s?pageNum_listAuthors=%d%s", $currentPage, max(0, $pageNum_listAuthors - 1), $queryString_listAuthors); ?>">Previous</a>
        <?php } // Show if not first page ?>
    </td>
    <td width="23%" align="center"><?php if ($pageNum_listAuthors < $totalPages_listAuthors) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_listAuthors=%d%s", $currentPage, min($totalPages_listAuthors, $pageNum_listAuthors + 1), $queryString_listAuthors); ?>">Next</a>
        <?php } // Show if not last page ?>
    </td>
    <td width="23%" align="center"><?php if ($pageNum_listAuthors < $totalPages_listAuthors) { // Show if not last page ?>
        <a href="<?php printf("%s?pageNum_listAuthors=%d%s", $currentPage, $totalPages_listAuthors, $queryString_listAuthors); ?>">Last</a>
        <?php } // Show if not last page ?>
    </td>
  </tr>
</table>
</body>
</html>
<?php
mysql_free_result($checkAuthor);

mysql_free_result($listAuthors);
?>