<?php require_once('Connections/seasonQuery.php'); ?>
<?php
$currentPage = $_SERVER["PHP_SELF"];

$maxRows_getPictures = 15;
$pageNum_getPictures = 0;
if (isset($_GET['pageNum_getPictures'])) {
  $pageNum_getPictures = $_GET['pageNum_getPictures'];
}
$startRow_getPictures = $pageNum_getPictures * $maxRows_getPictures;

mysql_select_db($database_seasonQuery, $seasonQuery);
$query_getPictures = "SELECT * FROM gallery";
$query_limit_getPictures = sprintf("%s LIMIT %d, %d", $query_getPictures, $startRow_getPictures, $maxRows_getPictures);
$getPictures = mysql_query($query_limit_getPictures, $seasonQuery) or die(mysql_error());
$row_getPictures = mysql_fetch_assoc($getPictures);

if (isset($_GET['totalRows_getPictures'])) {
  $totalRows_getPictures = $_GET['totalRows_getPictures'];
} else {
  $all_getPictures = mysql_query($query_getPictures);
  $totalRows_getPictures = mysql_num_rows($all_getPictures);
}
$totalPages_getPictures = ceil($totalRows_getPictures/$maxRows_getPictures)-1;

$queryString_getPictures = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_getPictures") == false && 
        stristr($param, "totalRows_getPictures") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_getPictures = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_getPictures = sprintf("&totalRows_getPictures=%d%s", $totalRows_getPictures, $queryString_getPictures);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons</title>
<?php include('style_rules.php'); ?>
</head>

<body>
<div id="wrapper">
  <div id="titlebar"><img src="images_common/bluebells_top.jpg" alt="East-West Seasons" width="738" height="122" /></div>
  <div id="maincontent">
    <div id="nav">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <h1>The changing seasons in Britain and Japan </h1>
    <div id="pictureWrapper">
      <div id="mainpic"><img <?php echo getDims($row_getPictures['image'], 'images_gallery/'); ?> src="images_gallery/<?php echo $row_getPictures['image']; ?>" alt="<?php echo $row_getPictures['caption']; ?>" /></div>
      <p id="picCaption"><?php echo $row_getPictures['caption']; ?></p>
    </div>
    <div id="thumbnails">
      <table>
        <tr>
          <?php
  do { // horizontal looper version 3
?>
            <td><img <?php echo getDims($row_getPictures['image'], 'images_gallery/thumbs/'); ?> src="images_gallery/thumbs/<?php echo $row_getPictures['image']; ?>" alt="<?php echo $row_getPictures['caption']; ?>" /></td>
            <?php
    $row_getPictures = mysql_fetch_assoc($getPictures);
    if (!isset($nested_getPictures)) {
      $nested_getPictures= 1;
    }
    if (isset($row_getPictures) && is_array($row_getPictures) && $nested_getPictures++ % 3==0) {
      echo "</tr><tr>";
    }
  } while ($row_getPictures); //end horizontal looper version 3
?>
        </tr>
      </table>
    
      <table id="pageNav">
        <tr>
          <td width="23%"><?php if ($pageNum_getPictures > 0) { // Show if not first page ?>
                <a href="<?php printf("%s?pageNum_getPictures=%d%s", $currentPage, 0, $queryString_getPictures); ?>"><img src="First.gif" border=0></a>
                <?php } // Show if not first page ?>
          </td>
          <td width="31%"><?php if ($pageNum_getPictures > 0) { // Show if not first page ?>
                <a href="<?php printf("%s?pageNum_getPictures=%d%s", $currentPage, max(0, $pageNum_getPictures - 1), $queryString_getPictures); ?>"><img src="Previous.gif" border=0></a>
                <?php } // Show if not first page ?>
          </td>
          <td width="23%"><?php if ($pageNum_getPictures < $totalPages_getPictures) { // Show if not last page ?>
                <a href="<?php printf("%s?pageNum_getPictures=%d%s", $currentPage, min($totalPages_getPictures, $pageNum_getPictures + 1), $queryString_getPictures); ?>"><img src="Next.gif" border=0></a>
                <?php } // Show if not last page ?>
          </td>
          <td width="23%"><?php if ($pageNum_getPictures < $totalPages_getPictures) { // Show if not last page ?>
                <a href="<?php printf("%s?pageNum_getPictures=%d%s", $currentPage, $totalPages_getPictures, $queryString_getPictures); ?>"><img src="Last.gif" border=0></a>
                <?php } // Show if not last page ?>
          </td>
        </tr>
      </table>
    </div>
  </div>
  <div id="footer"><?php include('copyright.php'); ?></div>
</div>
</body>
</html>
<?php
mysql_free_result($getPictures);

function getDims($image,$folder) {
  if (!empty($folder)) {
    if (strrpos($folder, '/') != strlen($folder)-1) {
      $folder .= '/';
      }
    }
  if(!empty($image) && file_exists($folder.$image)) {
    $image_info = getimagesize($folder.$image);
    }
  $retVal = isset($image_info) ? $image_info[3] : '';
  return $retVal;
  } 
?>
