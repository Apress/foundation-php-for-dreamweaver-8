<?php require_once('Connections/seasonQuery.php'); ?>
<?php
$var1_getArticle = "-1";
if (isset($_GET['article_id'])) {
  $var1_getArticle = (get_magic_quotes_gpc()) ? $_GET['article_id'] : addslashes($_GET['article_id']);
}
mysql_select_db($database_seasonQuery, $seasonQuery);
$query_getArticle = sprintf("SELECT blog.article_id, blog.title, blog.article, DATE_FORMAT(blog.created, '%%b %%e, %%Y') AS theDate, DATE_FORMAT(blog.updated, '%%l.%%i %%p on %%b %%e, %%Y') as latest, blog.updated, blog.created, blog.image, blog.caption FROM blog WHERE blog.article_id = %s", $var1_getArticle);
$getArticle = mysql_query($query_getArticle, $seasonQuery) or die(mysql_error());
$row_getArticle = mysql_fetch_assoc($getArticle);
$totalRows_getArticle = mysql_num_rows($getArticle);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons</title>
<?php include('style_rules.php'); ?>
</head>

<body>
<div id="wrapper">
  <div id="titlebar"><img src="images_common/bluebells_top.jpg" alt="East-West Seasons" width="738" height="122" /></div>
  <div id="maincontent">
    <div id="nav">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <h1><?php echo $row_getArticle['title']; ?></h1>
    <p><img src="images_blog/<?php echo $row_getArticle['image']; ?>" alt="<?php echo $row_getArticle['caption']; ?>" class="floatRight" /><strong><?php echo $row_getArticle['theDate']; ?>:</strong> <?php echo nl2br($row_getArticle['article']); ?></p>
	<?php if ($row_getArticle['updated'] != $row_getArticle['created']) { ?>
    <p>Last updated: <?php echo $row_getArticle['latest']; ?></p>
	<?php } ?>
    <p><a href="<?php
	// find if visitor was referred from a different domain
	$url = parse_url($_SERVER['HTTP_REFERER']);
	if ($url['host'] == $_SERVER['HTTP_HOST']) {
	  // if same domain, use referring URL
	  echo $_SERVER['HTTP_REFERER'];
	  }
	else {
	  // otherwise, send to main page
	  echo 'blog.php';
	  } ?>">Back to the blog</a></p>
  </div>
  <div id="footer"><?php include('copyright.php'); ?></div>
</div>
</body>
</html>
<?php
mysql_free_result($getArticle);
?>
