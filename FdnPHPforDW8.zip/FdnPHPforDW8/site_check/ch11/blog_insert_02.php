<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO blog (title, article, image, caption, created) VALUES (%s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['title'], "text"),
                       GetSQLValueString($_POST['article'], "text"),
                       GetSQLValueString($_POST['image'], "text"),
                       GetSQLValueString($_POST['caption'], "text"),
                       $_POST['created']);

  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $Result1 = mysql_query($insertSQL, $seasonAdmin) or die(mysql_error());
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Insert blog entry</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Insert blog entry 
</h1>

<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table align="center">
    <tr valign="baseline">
      <td nowrap align="right">Title:</td>
      <td><input name="title" type="text" class="widebox" value="" size="32" maxlength="255"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right" valign="top">Article:</td>
      <td><textarea name="article" cols="50" rows="5"></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">Image:</td>
      <td><select name="image">
        <option value="" >Select image</option>
		<?php buildImageList('../images_blog'); ?>
      </select>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">Caption:</td>
      <td><input name="caption" type="text" class="widebox" value="" size="32" maxlength="50"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" value="Insert record"></td>
    </tr>
  </table>
  <input type="hidden" name="created" value="NOW()">
  <input type="hidden" name="MM_insert" value="form1">
</form>
<p><a href="menu.php">Admin menu</a></p>
<p><a href="list_blog.php">List all blog entries</a>  </p>
</body>
</html>
<?php
function buildImageList($imageFolder, $recordset=NULL) {
// Check whether image folder has trailing slash, add if needed
$imageFolder = strrpos($imageFolder,'/') == strlen($imageFolder-1) ? $imageFolder : "$imageFolder/";
// Execute code if images folder can be opened, or fail silently
if ($theFolder = @opendir($imageFolder)) {
  // Create an array of image types
  $imageTypes = array('jpg','jpeg','gif','png');
  // Traverse images folder, and add filename to $img array if an image
  while (($imageFile = readdir($theFolder)) !== false) {
    $fileInfo = pathinfo($imageFile);
    if (in_array($fileInfo['extension'],$imageTypes)) {
      $img[] = $imageFile;
      }
    }
  // Close the stream from the images folder
  closedir($theFolder);
  // Check the $img array is not empty
  if ($img) {
    // Sort in natural, case-insensitive order, and populate menu
    natcasesort($img);
    foreach ($img as $image) {
      echo "<option value='$image'";
	  // Set selected image if recordset details supplied
	  if ($recordset != NULL && $recordset == $image) {
	    echo  ' selected="selected"';
		}
	  echo ">$image</option>\n";
      }
    }
  }
}
?>