-- phpMyAdmin SQL Dump
-- version 2.6.4-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Oct 14, 2005 at 04:20 PM
-- Server version: 5.0.13
-- PHP Version: 5.0.5
-- 
-- Database: `seasons`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `gallery`
-- 

CREATE TABLE `gallery` (
  `gallery_id` int(10) unsigned NOT NULL auto_increment,
  `image` varchar(50) NOT NULL default '',
  `caption` varchar(50) NOT NULL,
  PRIMARY KEY  (`gallery_id`)
) TYPE=MyISAM AUTO_INCREMENT=32 ;

-- 
-- Dumping data for table `gallery`
-- 

INSERT INTO `gallery` VALUES (1, 'ashtray.jpg', 'Tokyo street ashtray gets new use');
INSERT INTO `gallery` VALUES (2, 'azaleas.jpg', 'A blaze of color at Capel Manor in North London');
INSERT INTO `gallery` VALUES (3, 'buck_palace.jpg', 'Pelicans on the lake in St James''s Park, London');
INSERT INTO `gallery` VALUES (4, 'countrygarden.jpg', 'A typical English country garden in Oxford');
INSERT INTO `gallery` VALUES (5, 'daisydance.jpg', 'Dancing round the daisies at Capel Manor');
INSERT INTO `gallery` VALUES (6, 'dome.jpg', 'Leaden skies over the London Dome');
INSERT INTO `gallery` VALUES (7, 'eye_stjames.jpg', 'The London Eye frames the Foreign Office');
INSERT INTO `gallery` VALUES (8, 'fountain.jpg', 'Commemorative fountains in Tokyo');
INSERT INTO `gallery` VALUES (9, 'fountain02.jpg', 'More fountains in central Tokyo');
INSERT INTO `gallery` VALUES (10, 'greenpark.jpg', 'A summer''s day in Green Park, London');
INSERT INTO `gallery` VALUES (11, 'hgs.jpg', 'A quiet London suburb');
INSERT INTO `gallery` VALUES (12, 'imperial_plaza.jpg', 'Sculptured pine tree in Tokyo''s Imperial Plaza');
INSERT INTO `gallery` VALUES (13, 'imp_palace.jpg', 'View across the Imperial Palace moat, Tokyo');
INSERT INTO `gallery` VALUES (14, 'karuizawa_duck.jpg', 'Duck feeding on Kumoba Pond, Karuizawa');
INSERT INTO `gallery` VALUES (15, 'karuizawa_house.jpg', 'House in west Karuizawa');
INSERT INTO `gallery` VALUES (16, 'kumoba_pond.jpg', 'Autumn comes to Kumoba Pond, Karuizawa');
INSERT INTO `gallery` VALUES (17, 'mallgarden.jpg', 'The Queen''s ''front garden'' on The Mall in London');
INSERT INTO `gallery` VALUES (18, 'maples01.jpg', 'Autumn hues in Karuizawa');
INSERT INTO `gallery` VALUES (19, 'maples02.jpg', 'Maples set ablaze Kumoba Pond in Karuizawa');
INSERT INTO `gallery` VALUES (20, 'maples03.jpg', 'Maple leaves floating on water');
INSERT INTO `gallery` VALUES (21, 'maples04.jpg', 'Autumn hues in Karuizawa');
INSERT INTO `gallery` VALUES (22, 'moat.jpg', 'Imperial Palace moat, Tokyo');
INSERT INTO `gallery` VALUES (23, 'nest.jpg', 'Nesting time in Kenwood, Hampstead, North London');
INSERT INTO `gallery` VALUES (24, 'nijubashi.jpg', 'Nijubashi, Imperial Palace, Tokyo');
INSERT INTO `gallery` VALUES (25, 'rhododendron.jpg', 'Rhododendron in bloom in London garden');
INSERT INTO `gallery` VALUES (26, 'rose.jpg', 'A red, red rose');
INSERT INTO `gallery` VALUES (27, 'stjamespark.jpg', 'St James''s Park in Central London');
INSERT INTO `gallery` VALUES (28, 'summerfair.jpg', 'Enjoying the last days of summer at a fair');
INSERT INTO `gallery` VALUES (29, 'wadakura_bridge.jpg', 'Wadakura Bridge, Tokyo');
INSERT INTO `gallery` VALUES (30, 'whitecherry.jpg', 'Cherries bring a breath of spring to North London');
INSERT INTO `gallery` VALUES (31, 'whitecherry2.jpg', 'Cherries against a backdrop of fluffy white clouds');
