<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE blog SET title=%s, article=%s, image=%s, caption=%s WHERE article_id=%s",
                       GetSQLValueString($_POST['title'], "text"),
                       GetSQLValueString($_POST['article'], "text"),
                       GetSQLValueString($_POST['image'], "text"),
                       GetSQLValueString($_POST['caption'], "text"),
                       GetSQLValueString($_POST['article_id'], "int"));

  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $Result1 = mysql_query($updateSQL, $seasonAdmin) or die(mysql_error());

  $updateGoTo = "list_blog.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_getArticle = "-1";
if (isset($_GET['article_id'])) {
  $colname_getArticle = (get_magic_quotes_gpc()) ? $_GET['article_id'] : addslashes($_GET['article_id']);
}
mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_getArticle = sprintf("SELECT * FROM blog WHERE article_id = %s", $colname_getArticle);
$getArticle = mysql_query($query_getArticle, $seasonAdmin) or die(mysql_error());
$row_getArticle = mysql_fetch_assoc($getArticle);
$totalRows_getArticle = mysql_num_rows($getArticle);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update blog entry</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Update blog entry </h1>

<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table align="center">
    <tr valign="baseline">
      <td nowrap align="right">Title:</td>
      <td><input name="title" type="text" class="widebox" value="<?php echo $row_getArticle['title']; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right" valign="top">Article:</td>
      <td><textarea name="article" cols="50" rows="5"><?php echo $row_getArticle['article']; ?></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">Image:</td>
      <td><select name="image">
        <option value="" >No picture</option>
		<?php buildImageList('../images_blog/', $row_getArticle['image']); ?>
      </select>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">Caption:</td>
      <td><input name="caption" type="text" class="widebox" value="<?php echo $row_getArticle['caption']; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" value="Update record"></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="article_id" value="<?php echo $row_getArticle['article_id']; ?>">
</form>
<p><a href="menu.php">Admin menu</a></p>
<p><a href="list_blog.php">List all blog entries  </a></p>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($getArticle);

function buildImageList($imageFolder, $recordset=NULL) {
// Check whether image folder has trailing slash, add if needed
$imageFolder = strrpos($imageFolder,'/') == strlen($imageFolder-1) ? $imageFolder : "$imageFolder/";
// Execute code if images folder can be opened, or fail silently
if ($theFolder = @opendir($imageFolder)) {
  // Create an array of image types
  $imageTypes = array('jpg','jpeg','gif','png');
  // Traverse images folder, and add filename to $img array if an image
  while (($imageFile = readdir($theFolder)) !== false) {
    $fileInfo = pathinfo($imageFile);
    if (in_array($fileInfo['extension'],$imageTypes)) {
      $img[] = $imageFile;
      }
    }
  // Close the stream from the images folder
  closedir($theFolder);
  // Check the $img array is not empty
  if ($img) {
    // Sort in natural, case-insensitive order, and populate menu
    natcasesort($img);
    foreach ($img as $image) {
      echo "<option value='$image'";
	  // Set selected image if recordset details supplied
	  if ($recordset != NULL && $recordset == $image) {
	    echo  ' selected="selected"';
		}
	  echo ">$image</option>\n";
      }
    }
  }
}
?>
