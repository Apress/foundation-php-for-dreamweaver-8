<?php require_once('Connections/seasonQuery.php'); ?>
<?php
$maxRows_getArticles = 2;
$pageNum_getArticles = 0;
if (isset($_GET['pageNum_getArticles'])) {
  $pageNum_getArticles = $_GET['pageNum_getArticles'];
}
$startRow_getArticles = $pageNum_getArticles * $maxRows_getArticles;

mysql_select_db($database_seasonQuery, $seasonQuery);
$query_getArticles = "SELECT blog.article_id, blog.title, blog.article,DATE_FORMAT(blog.created, '%b %e, %Y') AS theDate FROM blog ORDER BY blog.created DESC";
$query_limit_getArticles = sprintf("%s LIMIT %d, %d", $query_getArticles, $startRow_getArticles, $maxRows_getArticles);
$getArticles = mysql_query($query_limit_getArticles, $seasonQuery) or die(mysql_error());
$row_getArticles = mysql_fetch_assoc($getArticles);

if (isset($_GET['totalRows_getArticles'])) {
  $totalRows_getArticles = $_GET['totalRows_getArticles'];
} else {
  $all_getArticles = mysql_query($query_getArticles);
  $totalRows_getArticles = mysql_num_rows($all_getArticles);
}
$totalPages_getArticles = ceil($totalRows_getArticles/$maxRows_getArticles)-1;
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons</title>
<?php include('style_rules.php'); ?>
</head>

<body>
<div id="wrapper">
  <div id="titlebar"><img src="images_common/bluebells_top.jpg" alt="East-West Seasons" width="738" height="122" /></div>
  <div id="maincontent">
    <div id="nav">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <?php do { ?>
      <h2><?php echo $row_getArticles['title']; ?></h2>
      <p><strong><?php echo $row_getArticles['theDate']; ?>:</strong> <?php echo $row_getArticles['article']; ?> <a href="blog_detail.php?article_id=<?php echo $row_getArticles['article_id']; ?>">More</a> </p>
      <?php } while ($row_getArticles = mysql_fetch_assoc($getArticles)); ?></div>
  <div id="footer"><?php include('copyright.php'); ?></div>
</div>
</body>
</html>
<?php
mysql_free_result($getArticles);
?>
