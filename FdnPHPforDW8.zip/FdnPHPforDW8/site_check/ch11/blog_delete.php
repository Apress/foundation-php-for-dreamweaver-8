<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

if ((isset($_POST['article_id'])) && ($_POST['article_id'] != "")) {
  $deleteSQL = sprintf("DELETE FROM blog WHERE article_id=%s",
                       GetSQLValueString($_POST['article_id'], "int"));

  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $Result1 = mysql_query($deleteSQL, $seasonAdmin) or die(mysql_error());

  $deleteGoTo = "list_blog.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$colname_getArticle = "-1";
if (isset($_GET['article_id'])) {
  $colname_getArticle = (get_magic_quotes_gpc()) ? $_GET['article_id'] : addslashes($_GET['article_id']);
}
mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_getArticle = sprintf("SELECT * FROM blog WHERE article_id = %s", $colname_getArticle);
$getArticle = mysql_query($query_getArticle, $seasonAdmin) or die(mysql_error());
$row_getArticle = mysql_fetch_assoc($getArticle);
$totalRows_getArticle = mysql_num_rows($getArticle);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Delete blog entry</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Delete blog entry</h1>
<p class="warning">Please confirm that you want to delete the following record. This action cannot be undone.</p>
<form id="delRecord" name="delRecord" method="post" action="">
  <p><?php echo $row_getArticle['created']; ?> <?php echo $row_getArticle['title']; ?>
    <input name="article_id" type="hidden" id="article_id" value="<?php echo $row_getArticle['article_id']; ?>" />
  </p>
  <p>
    <input name="delete" type="submit" id="delete" value="Confirm deletion" />
  </p>
</form>
<p><a href="menu.php">Admin menu</a></p>
<p><a href="list_blog.php">List blog entries  </a></p>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($getArticle);
?>
