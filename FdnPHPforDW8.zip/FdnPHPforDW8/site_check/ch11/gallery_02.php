<?php require_once('Connections/seasonQuery.php'); ?>
<?php
mysql_select_db($database_seasonQuery, $seasonQuery);
$query_getPictures = "SELECT * FROM gallery";
$getPictures = mysql_query($query_getPictures, $seasonQuery) or die(mysql_error());
$row_getPictures = mysql_fetch_assoc($getPictures);
$totalRows_getPictures = mysql_num_rows($getPictures);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons</title>
<?php include('style_rules.php'); ?>
</head>

<body>
<div id="wrapper">
  <div id="titlebar"><img src="images_common/bluebells_top.jpg" alt="East-West Seasons" width="738" height="122" /></div>
  <div id="maincontent">
    <div id="nav">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <h1>The changing seasons in Britain and Japan </h1>
    <div id="pictureWrapper">
      <div id="mainpic"><img <?php echo getDims($row_getPictures['image'], 'images_gallery/'); ?> src="images_gallery/<?php echo $row_getPictures['image']; ?>" alt="<?php echo $row_getPictures['caption']; ?>" /></div>
      <p id="picCaption"><?php echo $row_getPictures['caption']; ?></p></div>
  </div>
  <div id="footer"><?php include('copyright.php'); ?></div>
</div>
</body>
</html>
<?php
mysql_free_result($getPictures);

function getDims($image,$folder) {
  if (!empty($folder)) {
    if (strrpos($folder, '/') != strlen($folder)-1) {
      $folder .= '/';
      }
    }
  if(!empty($image) && file_exists($folder.$image)) {
    $image_info = getimagesize($folder.$image);
    }
  $retVal = isset($image_info) ? $image_info[3] : '';
  return $retVal;
  } 
?>
