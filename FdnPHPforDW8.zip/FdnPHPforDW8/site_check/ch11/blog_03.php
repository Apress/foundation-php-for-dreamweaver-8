<?php require_once('Connections/seasonQuery.php'); ?>
<?php
$currentPage = $_SERVER["PHP_SELF"];

$maxRows_getArticles = 2;
$pageNum_getArticles = 0;
if (isset($_GET['pageNum_getArticles'])) {
  $pageNum_getArticles = $_GET['pageNum_getArticles'];
}
$startRow_getArticles = $pageNum_getArticles * $maxRows_getArticles;

mysql_select_db($database_seasonQuery, $seasonQuery);
$query_getArticles = "SELECT blog.article_id, blog.title, blog.article,DATE_FORMAT(blog.created, '%b %e, %Y') AS theDate FROM blog ORDER BY blog.created DESC";
$query_limit_getArticles = sprintf("%s LIMIT %d, %d", $query_getArticles, $startRow_getArticles, $maxRows_getArticles);
$getArticles = mysql_query($query_limit_getArticles, $seasonQuery) or die(mysql_error());
$row_getArticles = mysql_fetch_assoc($getArticles);

if (isset($_GET['totalRows_getArticles'])) {
  $totalRows_getArticles = $_GET['totalRows_getArticles'];
} else {
  $all_getArticles = mysql_query($query_getArticles);
  $totalRows_getArticles = mysql_num_rows($all_getArticles);
}
$totalPages_getArticles = ceil($totalRows_getArticles/$maxRows_getArticles)-1;

$queryString_getArticles = "";
if (!empty($_SERVER['QUERY_STRING'])) {
  $params = explode("&", $_SERVER['QUERY_STRING']);
  $newParams = array();
  foreach ($params as $param) {
    if (stristr($param, "pageNum_getArticles") == false && 
        stristr($param, "totalRows_getArticles") == false) {
      array_push($newParams, $param);
    }
  }
  if (count($newParams) != 0) {
    $queryString_getArticles = "&" . htmlentities(implode("&", $newParams));
  }
}
$queryString_getArticles = sprintf("&totalRows_getArticles=%d%s", $totalRows_getArticles, $queryString_getArticles);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons</title>
<?php include('style_rules.php'); ?>
</head>

<body>
<div id="wrapper">
  <div id="titlebar"><img src="images_common/bluebells_top.jpg" alt="East-West Seasons" width="738" height="122" /></div>
  <div id="maincontent">
    <div id="nav">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <?php do { ?>
      <h2><?php echo $row_getArticles['title']; ?></h2>
      <p><strong><?php echo $row_getArticles['theDate']; ?>:</strong>
	  <?php $extract = getFirst($row_getArticles['article']);
	  echo $extract[0];
	  if ($extract[1]) { ?> <a href="blog_detail.php?article_id=<?php echo $row_getArticles['article_id']; ?>">More</a> <?php } ?></p>
      <?php } while ($row_getArticles = mysql_fetch_assoc($getArticles)); ?>
      <table border="0" width="50%" align="center">
        <tr>
          <td width="23%" align="center"><?php if ($pageNum_getArticles > 0) { // Show if not first page ?>
                <a href="<?php printf("%s?pageNum_getArticles=%d%s", $currentPage, 0, $queryString_getArticles); ?>">First</a>
                <?php } // Show if not first page ?>
          </td>
          <td width="31%" align="center"><?php if ($pageNum_getArticles > 0) { // Show if not first page ?>
                <a href="<?php printf("%s?pageNum_getArticles=%d%s", $currentPage, max(0, $pageNum_getArticles - 1), $queryString_getArticles); ?>">Previous</a>
                <?php } // Show if not first page ?>
          </td>
          <td width="23%" align="center"><?php if ($pageNum_getArticles < $totalPages_getArticles) { // Show if not last page ?>
                <a href="<?php printf("%s?pageNum_getArticles=%d%s", $currentPage, min($totalPages_getArticles, $pageNum_getArticles + 1), $queryString_getArticles); ?>">Next</a>
                <?php } // Show if not last page ?>
          </td>
          <td width="23%" align="center"><?php if ($pageNum_getArticles < $totalPages_getArticles) { // Show if not last page ?>
                <a href="<?php printf("%s?pageNum_getArticles=%d%s", $currentPage, $totalPages_getArticles, $queryString_getArticles); ?>">Last</a>
                <?php } // Show if not last page ?>
          </td>
        </tr>
      </table>
  </div>
  <div id="footer"><?php include('copyright.php'); ?></div>
</div>
</body>
</html>
<?php
mysql_free_result($getArticles);

function getFirst($text, $number=2) {
  // regular expression to find typical sentence endings
  $pattern = '/([.?!]["\']?)\s/';
  // use regex to insert break indicator
  $text = preg_replace($pattern, '$1bRE@kH3re', $text);
  // use break indicator to create array of sentences
  $sentences = explode('bRE@kH3re', $text);
  // check relative length of array and requested number
  $howMany = count($sentences);
  $number = $howMany >= $number ? $number : $howMany;
  // rebuild extract and return as single string
  $remainder = array_splice($sentences, $number);
  $result = array();
  $result[0] = implode(' ', $sentences);
  $result[1] = empty($remainder) ? false : true;
  return $result;
  }
?>
