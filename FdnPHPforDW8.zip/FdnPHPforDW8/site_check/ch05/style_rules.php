<link href="styles/basic.css" rel="stylesheet" type="text/css" media="screen" />
<style type="text/css" media="screen">
@import url("styles/bluebells.css");
</style>
<!--[if IE 5]>
<style>
body {text-align: center;}
#wrapper {text-align: left;}
#nav a {width: 146px;}
</style>
<![endif]-->