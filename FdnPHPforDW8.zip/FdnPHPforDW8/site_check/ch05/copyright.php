<p>&copy; 
<?php
// define the starting year
$startYear = 2005;
// calculate the current year
$thisYear = date('Y');

if ($startYear == $thisYear) {
  // if both are the saem, just show the starting year
  echo $startYear;
  }
else {
  // if they're different, show both
  echo "$startYear-$thisYear";
  }
?> David Powers</p>
