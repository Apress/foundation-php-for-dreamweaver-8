<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
if (isset($_POST['pwd'])) { $_POST['pwd'] = sha1($_POST['pwd']); }
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['username'])) {
  $loginUsername=$_POST['username'];
  $password=$_POST['pwd'];
  $MM_fldUserAuthorization = "admin_priv";
  $MM_redirectLoginSuccess = "menu.php";
  $MM_redirectLoginFailed = "loginfail.php";
  $MM_redirecttoReferrer = true;
  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  	
  $LoginRS__query=sprintf("SELECT username, pwd, admin_priv FROM users WHERE username='%s' AND pwd='%s'",
  get_magic_quotes_gpc() ? $loginUsername : addslashes($loginUsername), get_magic_quotes_gpc() ? $password : addslashes($password)); 
   
  $LoginRS = mysql_query($LoginRS__query, $seasonAdmin) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
    
    $loginStrGroup  = mysql_result($LoginRS,0,'admin_priv');
    
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && true) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Admin login</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>East-West Seasons administration login </h1>
<form ACTION="<?php echo $loginFormAction; ?>" id="login" name="login" method="POST">
  <p>
    <label for="username">Username:</label>
    <br />
    <input type="text" name="username" id="username" />
  </p>
  <p>
    <label for="pwd">Password:</label>
    <br />
    <input type="password" name="pwd" id="pwd" />
  </p>
  <p>
    <input name="doLogin" type="submit" id="doLogin" value="Log in" />
  </p>
</form>
</body>
</html>
