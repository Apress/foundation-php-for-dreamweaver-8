<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_listUsers = "SELECT * FROM users ORDER BY users.family_name, users.first_name";
$listUsers = mysql_query($query_listUsers, $seasonAdmin) or die(mysql_error());
$row_listUsers = mysql_fetch_assoc($listUsers);
$totalRows_listUsers = mysql_num_rows($listUsers);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Registered users</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Registered users </h1>
<table width="600" cellpadding="4">
  <tr>
    <th scope="col">Name</th>
    <th scope="col">Username</th>
    <th scope="col">Admin</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <?php do { ?>
  <tr>
    <td><?php echo $row_listUsers['first_name']; ?> <?php echo strtoupper($row_listUsers['family_name']); ?></td>
    <td><?php echo $row_listUsers['username']; ?></td>
    <td class="centered"><?php echo $row_listUsers['admin_priv']; ?></td>
    <td><a href="updateuser.php?user_id=<?php echo $row_listUsers['user_id']; ?>">EDIT</a></td>
    <td><a href="deleteuser.php?user_id=<?php echo $row_listUsers['user_id']; ?>">DELETE</a></td>
  </tr>
  <?php } while ($row_listUsers = mysql_fetch_assoc($listUsers)); ?>
</table>
</body>
</html>
<?php
mysql_free_result($listUsers);
?>
