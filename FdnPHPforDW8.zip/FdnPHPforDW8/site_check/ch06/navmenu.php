<?php
$pages = array('index.php'   => 'Home',
               'news.php'    => 'News',
               'blog.php'    => 'Blog',
               'gallery.php' => 'Gallery',
               'contact.php' => 'Contact');

function insertMenu($pages, $pageID) {
  echo "<ul>\n";
  foreach ($pages as $file => $listing) {
    echo '<li';
    // if the current filename and array key match, insert ID
    if (basename($_SERVER['SCRIPT_FILENAME']) == $file) {
      echo " id='$pageID'><a href='javascript:;'>";
      }
    else {
      echo "><a href='$file'>";
      }
    echo "$listing</a></li>\n";
    }
  echo "</ul>\n";
  }
?>