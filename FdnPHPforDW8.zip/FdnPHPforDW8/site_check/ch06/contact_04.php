<?php
if (array_key_exists('ewComments', $_POST)) {
  // mail processing script
  // remove escape characters from POST array
if (get_magic_quotes_gpc()) {
  function stripslashes_deep($value) {
    $value = is_array($value) ? array_map('stripslashes_deep', $value) : stripslashes($value);
    return $value;
    }
  $_POST = array_map('stripslashes_deep', $_POST);
  }
  // initialize variables
  $to = 'me@example.com'; // use your own email address
  $subject = 'Feedback from East-West Seasons';
  
  // build the message
  $message = 'From: '.$_POST['name']."\n\n";
  $message .= 'Email: '.$_POST['email']."\n\n";
  $message .= 'Comments: '.$_POST['message'];
  
  //build the additional headers
  $additionalHeaders = "From: E-W Seasons<feedback@example.com>\r\n";
  $additionalHeaders .= 'Reply-To: '.$_POST['email'];
  
  // send the email
  mail($to, $subject, $message, $additionalHeaders);
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons</title>
<?php include('style_rules.php'); ?>
</head>

<body>
<div id="wrapper">
  <div id="titlebar"><img src="images_common/bluebells_top.jpg" alt="East-West Seasons" width="738" height="122" /></div>
  <div id="maincontent">
    <div id="nav">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <h1>Send us your comments</h1>
    <p>We hope you have enjoyed this site. If you have any comments, or would like further information, please use the following form. East-West Seasons will not use your email address for any other purpose than replying to you. </p>
    <form id="contactForm" name="contactForm" method="post" action="<?php $_SERVER['PHP_SELF']; ?>">
      <p>
        <label for="name">Name:</label>
        <br />
        <input type="text" name="name" id="name" />
      </p>
      <p>
        <label for="email">Email:</label>
        <br />
        <input type="text" name="email" id="email" />
      </p>
      <p>
        <label for="message">Message:</label>
        <br />
        <textarea name="message" id="message"></textarea>
      </p>
      <p>
        <input name="ewComments" type="submit" id="ewComments" value="Send comments" />
      </p>
    </form>
  </div>
  <div id="footer"><?php include('copyright.php'); ?></div>
</div>
</body>
</html>
