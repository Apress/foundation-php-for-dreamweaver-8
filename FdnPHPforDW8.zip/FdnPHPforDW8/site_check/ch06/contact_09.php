<?php
// set flag to indicate whether mail has been sent
$mailSent = false;
if (array_key_exists('ewComments', $_POST)) {
  // mail processing script
  // remove escape characters from POST array
if (get_magic_quotes_gpc()) {
  function stripslashes_deep($value) {
    $value = is_array($value) ? array_map('stripslashes_deep', $value) : stripslashes($value);
    return $value;
    }
  $_POST = array_map('stripslashes_deep', $_POST);
  }
  // validate the input, beginning with name
  $name = trim($_POST['name']);
  if (empty($name)) {
    $error['name'] = 'Please enter your name';
    }
  $email = $_POST['email'];
  // check for valid email address
  $pattern = '/^[^@]+@[^\s\r\n\'";,@%]+$/';
  if (!preg_match($pattern, trim($email))) {
    $error['email'] = 'Please enter a valid email address';
    }
  // check the content of the text area
  $messageBody = trim($_POST['message']);
  if (empty($messageBody)) {
    $error['message'] = 'Please enter your message';
    }
  // initialize variables
  $to = 'me@example.com'; // use your own email address
  $subject = 'Feedback from East-West Seasons';
  
  // build the message
  $message = 'On '.date('l, M j, Y').' at '.date('g:ia').', ';
  $message .= "$name ($email) wrote: \n\n";
  $message .= $messageBody;

  //build the additional headers
  $additionalHeaders = "From: E-W Seasons<feedback@example.com>\r\n";
  $additionalHeaders .= "Reply-To: $email";

  if (!isset($error)) {
    $mailSent = mail($to, $subject, $message, $additionalHeaders);
    // check that the mail was sent successfully
    if (!$mailSent) {
      $error['notSent'] = 'Sorry, there was a problem sending your mail. Please try later.';
      }
    }
  }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons</title>
<?php include('style_rules.php'); ?>
<script type="text/JavaScript">
<!--
function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_validateForm() { //v4.0
  var i,p,q,nm,test,num,min,max,errors='',args=MM_validateForm.arguments;
  for (i=0; i<(args.length-2); i+=3) { test=args[i+2]; val=MM_findObj(args[i]);
    if (val) { nm=val.name; if ((val=val.value)!="") {
      if (test.indexOf('isEmail')!=-1) { p=val.indexOf('@');
        if (p<1 || p==(val.length-1)) errors+='- '+nm+' must contain an e-mail address.\n';
      } else if (test!='R') { num = parseFloat(val);
        if (isNaN(val)) errors+='- '+nm+' must contain a number.\n';
        if (test.indexOf('inRange') != -1) { p=test.indexOf(':');
          min=test.substring(8,p); max=test.substring(p+1);
          if (num<min || max<num) errors+='- '+nm+' must contain a number between '+min+' and '+max+'.\n';
    } } } else if (test.charAt(0) == 'R') errors += '- '+nm+' is required.\n'; }
  } if (errors) alert('The following error(s) occurred:\n'+errors);
  document.MM_returnValue = (errors == '');
}
//-->
</script>
</head>

<body>
<div id="wrapper">
  <div id="titlebar"><img src="images_common/bluebells_top.jpg" alt="East-West Seasons" width="738" height="122" /></div>
  <div id="maincontent">
    <div id="nav">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
	<?php if (isset($error['notSent'])) { ?>
    <h1>Server error</h1>
    <p class="warning"><?php echo $error['notSent']; ?></p>
	<?php } elseif ($mailSent) { ?>
    <h1>Thank you for your comments</h1>
    <p>We appreciate your feedback, and will be in touch if necessary.</p>
	<?php } else { ?>
    <h1>Send us your comments</h1>
    <p>We hope you have enjoyed this site. If you have any comments, or would like further information, please use the following form. East-West Seasons will not use your email address for any other purpose than replying to you. </p>
	<?php } ?>
	<?php if (!$mailSent) { ?>
    <form action="<?php $_SERVER['PHP_SELF']; ?>" method="post" name="contactForm" id="contactForm" onsubmit="MM_validateForm('name','','R','email','','RisEmail','message','','R');return document.MM_returnValue">
      <p>
        <label for="name">Name:</label> <?php if (isset($error['name'])) { ?>
        <span class="warning"><?php echo $error['name']; ?></span>
        <?php } ?>
        <br />
        <input type="text" name="name" id="name"
		<?php if(isset($error)) {echo "value='$name'";} ?> />
      </p>
      <p>
        <label for="email">Email:</label> <?php if (isset($error['email'])) { ?>
        <span class="warning"><?php echo $error['email']; ?></span>
        <?php } ?>
        <br />
        <input type="text" name="email" id="email"
		<?php if(isset($error)) {echo "value='$email'";} ?> />
      </p>
      <p>
        <label for="message">Message:</label> <?php if (isset($error['message'])) { ?>
        <span class="warning"><?php echo $error['message']; ?></span>
        <?php } ?>
        <br />
        <textarea name="message" id="message"><?php if(isset($error)) {echo $messageBody;} ?></textarea>
      </p>
      <p>
        <input name="ewComments" type="submit" id="ewComments" value="Send comments" />
      </p>
    </form>
	<?php } ?>
  </div>
  <div id="footer"><?php include('copyright.php'); ?></div>
</div>
</body>
</html>
