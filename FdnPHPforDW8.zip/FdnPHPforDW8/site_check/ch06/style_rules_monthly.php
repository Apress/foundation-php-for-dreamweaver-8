<link href="styles/basic.css" rel="stylesheet" type="text/css" media="screen" />
<?php
// get current month as a number
$month = date('n');
// select theme for the month
switch($month) {
  case 10:
  case 11:
  case 12:
  case 8:
    $theme = 'maples';
    break;
  case 2:
  case 3:
  case 4:
    $theme = 'bluebells';
    break;
  default:
    $theme = 'tulips';
  }
?>
<style type="text/css">
/* apply the theme for the current month */
@import url("styles/<?php echo $theme; ?>.css");
</style>
<!--[if IE 5]>
<style>
body {text-align: center;}
#wrapper {text-align: left;}
#nav a {width: 146px;}
</style>
<![endif]-->