<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = (!get_magic_quotes_gpc()) ? addslashes($theValue) : $theValue;

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form1")) {
  $updateSQL = sprintf("UPDATE quotations SET first_name=%s, family_name=%s, quotation=%s WHERE quote_id=%s",
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['family_name'], "text"),
                       GetSQLValueString($_POST['quotation'], "text"),
                       GetSQLValueString($_POST['quote_id'], "int"));

  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $Result1 = mysql_query($updateSQL, $seasonAdmin) or die(mysql_error());

  $updateGoTo = "quote_list.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}

$colname_getQuote = "-1";
if (isset($_GET['quote_id'])) {
  $colname_getQuote = (get_magic_quotes_gpc()) ? $_GET['quote_id'] : addslashes($_GET['quote_id']);
}
mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_getQuote = sprintf("SELECT * FROM quotations WHERE quote_id = %s", $colname_getQuote);
$getQuote = mysql_query($query_getQuote, $seasonAdmin) or die(mysql_error());
$row_getQuote = mysql_fetch_assoc($getQuote);
$totalRows_getQuote = mysql_num_rows($getQuote);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update quotation</title>
</head>

<body>
<h1>Update quotation </h1>

<form method="post" name="form1" action="<?php echo $editFormAction; ?>">
  <table align="center">
    <tr valign="baseline">
      <td nowrap align="right">First name:</td>
      <td><input type="text" name="first_name" value="<?php echo $row_getQuote['first_name']; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">Family name:</td>
      <td><input type="text" name="family_name" value="<?php echo $row_getQuote['family_name']; ?>" size="32"></td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right" valign="top">Quotation:</td>
      <td><textarea name="quotation" cols="50" rows="5"><?php echo $row_getQuote['quotation']; ?></textarea>
      </td>
    </tr>
    <tr valign="baseline">
      <td nowrap align="right">&nbsp;</td>
      <td><input type="submit" value="Update record"></td>
    </tr>
  </table>
  <input type="hidden" name="MM_update" value="form1">
  <input type="hidden" name="quote_id" value="<?php echo $row_getQuote['quote_id']; ?>">
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($getQuote);
?>
