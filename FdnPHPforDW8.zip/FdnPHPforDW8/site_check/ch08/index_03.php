<?php require_once('Connections/seasonQuery.php'); ?>
<?php
mysql_select_db($database_seasonQuery, $seasonQuery);
$query_getQuote = "SELECT * FROM quotations ORDER BY RAND() LIMIT 1";
$getQuote = mysql_query($query_getQuote, $seasonQuery) or die(mysql_error());
$row_getQuote = mysql_fetch_assoc($getQuote);
$totalRows_getQuote = mysql_num_rows($getQuote);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons</title>
<?php include('style_rules.php'); ?>
</head>

<body>
<div id="wrapper">
  <div id="titlebar"><img src="images_common/bluebells_top.jpg" alt="East-West Seasons" width="738" height="122" /></div>
  <div id="maincontent">
    <div id="nav">
      <ul>
        <li id="thispage"><a href="index.php">Home</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <h1>This is a heading </h1>
    <p>Ut enim ad minim veniam, excepteur sint occaecat duis aute irure dolor. Ut aliquip ex ea commodo consequat. Sunt in culpa ullamco laboris nisi cupidatat non proident. Sed do eiusmod tempor incididunt duis aute irure dolor lorem ipsum dolor sit amet.</p>
    <blockquote>
      <p><?php echo $row_getQuote['quotation']; ?></p>
      <p><?php echo $row_getQuote['first_name']; ?> <?php echo $row_getQuote['family_name']; ?></p>
    </blockquote>
    <p>Ut labore et dolore magna aliqua. Mollit anim id est laborum. Consectetur adipisicing elit, sunt in culpa ut aliquip ex ea commodo consequat. Cupidatat non proident, eu fugiat nulla pariatur.</p>
    <h2>And here is some more content </h2>
    <p>Sed do eiusmod tempor incididunt in reprehenderit in voluptate ullamco laboris nisi. Duis aute irure dolor cupidatat non proident, consectetur adipisicing elit. Excepteur sint occaecat mollit anim id est laborum. Ut enim ad minim veniam, quis nostrud exercitation sunt in culpa. In reprehenderit in voluptate ut labore et dolore magna aliqua.</p>
    <p>Qui officia deserunt ullamco laboris nisi lorem ipsum dolor sit amet. Quis nostrud exercitation. Eu fugiat nulla pariatur. Consectetur adipisicing elit, velit esse cillum dolore sunt in culpa. In reprehenderit in voluptate qui officia deserunt ullamco laboris nisi.</p>
    <p>Lorem ipsum dolor sit amet, ut aliquip ex ea commodo consequat. Quis nostrud exercitation excepteur sint occaecat sed do eiusmod tempor incididunt. Cupidatat non proident, duis aute irure dolor ut labore et dolore magna aliqua.</p>
</div>
  <div id="footer"><?php include('copyright.php'); ?></div>
</div>
</body>
</html>
<?php
mysql_free_result($getQuote);
?>
