FOUNDATION PHP FOR DREAMWEAVER 8 (ISBN: 1590595696)
***************************************************

There are six folders, which contain all the files necessary for completing the case study and exercises in the book:

examples
extensions
images_blog
images_common
images_gallery
site_check

The examples and site_check folders contain subfolders organized by chapter.

Instructions for organizing the download files for the case study can be found on pages 101-102 of the book.

When moving any of the PHP files from one folder to another, do NOT let Dreamweaver update any of the links. All the relative paths in the files are the way they should be in the final site. This is to make it easier for you to use Dreamweaver 8's File Compare feature, as described on pages 26-31 of the book.

UPDATED VERSION OF LOREM AND MORE EXTENSION

The extensions folder contains Lorem_andMore1_22.mxp, and not Lorem_andMore1_21.mxp as shown on page 103. This is an updated version, which incorporates a minor revision suggested by a Macromedia engineer following the discovery of a bug in Dreamweaver 8 that prevented the extension displaying the control buttons in certain circumstances.

PROBLEMS, ERRORS, UPDATES

If you have any problems with the files, please post a message on the friends of ED forum at http://www.friendsofed.com/forums/. Also check the book's page at http://www.friendsofed.com/books/1590595696/. Any updates and errors will be listed on the book's errata page.