<?php session_start(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Quirks test</title>
<style type="text/css">
<!--
#maincontent {
	width: 300px;
	padding-right: 75px;
	padding-left: 75px;
	border: medium solid #009900;
}
-->
</style>
</head>

<body>
<div id="maincontent">
  <p>Now is the time for all good men to come to the aid of the party. </p>
</div>
</body>
</html>
