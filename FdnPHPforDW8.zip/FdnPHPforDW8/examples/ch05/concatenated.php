<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Concatenated string</title>
</head>
<body>
<?php
$tweedledee = "'The time has come,' the Walrus said,\n";
$tweedledee = $tweedledee."'To talk of many things:\n";
$tweedledee = $tweedledee."Of shoes, and ships, and sealing wax,\n";
$tweedledee = $tweedledee."Of cabbages, and kings,\n";
$tweedledee = $tweedledee."And why the sea is boiling hot,\n";
$tweedledee = $tweedledee."And whether pigs have wings.'";
echo $tweedledee;
?>
</body>
</html>
