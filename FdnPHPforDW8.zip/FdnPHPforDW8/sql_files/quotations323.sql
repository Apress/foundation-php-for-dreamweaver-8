-- phpMyAdmin SQL Dump
-- version 2.6.3-pl1
-- http://www.phpmyadmin.net
-- 
-- Host: localhost
-- Generation Time: Aug 24, 2005 at 12:33 PM
-- Server version: 4.1.13
-- PHP Version: 5.0.4
-- 
-- Database: `seasons`
-- 

-- --------------------------------------------------------

-- 
-- Table structure for table `quotations`
-- 

DROP TABLE IF EXISTS `quotations`;
CREATE TABLE `quotations` (
  `quote_id` int(10) unsigned NOT NULL auto_increment,
  `quotation` varchar(255) NOT NULL default '',
  `first_name` varchar(30) NOT NULL default '',
  `family_name` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`quote_id`)
) TYPE=MyISAM;

-- 
-- Dumping data for table `quotations`
-- 

INSERT INTO `quotations` VALUES (1, 'My disability is that I cannot use my legs. My handicap is your negative perception of that disability, and thus of me.', 'Rick', 'Hansen');
INSERT INTO `quotations` VALUES (2, 'Life is a great surprise. I do not see why death should not be an even greater one.', 'Vladimir', 'Nabokov');
INSERT INTO `quotations` VALUES (3, 'Money couldn''t buy friends, but you got a better class of enemy.', 'Spike', 'Milligan');
INSERT INTO `quotations` VALUES (4, 'In the factory we make cosmetics; in the store we sell hope.', 'Charles', 'Revson');
INSERT INTO `quotations` VALUES (5, 'Man is the only animal that blushes. Or needs to.', 'Mark', 'Twain');
INSERT INTO `quotations` VALUES (6, 'Familiarity breeds contempt &#8212; and children.', 'Mark', 'Twain');
INSERT INTO `quotations` VALUES (7, 'Good breeding consists in concealing how much we think of ourselves and how little we think of the other person.', 'M', 'Twain');
INSERT INTO `quotations` VALUES (8, 'If it turns out that there is a God, I don''t think that he''s evil. But the worst that you can say about him is that basically, he''s an underachiever.', 'Woody', 'Allen');
INSERT INTO `quotations` VALUES (9, 'I don''t want to achieve immortality through my work... I want to achieve it by not dying.', 'Woody', 'Allen');
INSERT INTO `quotations` VALUES (10, 'A thing of beauty is a joy forever.', 'John', 'Keats');
INSERT INTO `quotations` VALUES (11, 'Scenery is fine &#8212; but human nature is finer.', 'John', 'Keats');
INSERT INTO `quotations` VALUES (12, 'The nice aspect about football is that, if things go wrong, it''s the manager who gets the blame.', 'Gary', 'Lineker');
INSERT INTO `quotations` VALUES (13, 'Iron rusts from disuse; stagnant water loses its purity and in cold weather becomes frozen; even so does inaction sap the vigor of the mind.', 'Leonardo', 'da Vinci');
INSERT INTO `quotations` VALUES (14, 'A hundred times I have thought: New York is a catastrophe, and fifty times: it is a beautiful catastrophe.', '', 'Le Corbusier');
INSERT INTO `quotations` VALUES (15, 'Power is the great aphrodisiac.', 'Henry', 'Kissinger');
INSERT INTO `quotations` VALUES (16, 'Injustice anywhere is a threat to justice everywhere.', 'Martin Luther', 'King');
INSERT INTO `quotations` VALUES (17, 'Democracy is the worst form of government except all those other forms that have been tried from time to time.', 'Winston', 'Churchill');
INSERT INTO `quotations` VALUES (18, 'Love, friendship, respect do not unite people as much as common hatred for something.', 'Anton', 'Chekhov');
INSERT INTO `quotations` VALUES (19, 'Everything''s got a moral, if only you can find it.', 'Lewis', 'Carroll');
INSERT INTO `quotations` VALUES (20, 'The greatest happiness of the greatest number is the foundation of morals and legislation.', 'Jeremy', 'Bentham');
INSERT INTO `quotations` VALUES (21, 'There''s a hell of a distance between wise-cracking and wit. Wit has truth in it; wise-cracking is simply callisthenics with words.', 'Dorothy', 'Parker');
INSERT INTO `quotations` VALUES (22, 'Summers pleasures they are gone like to visions every one.', 'John', 'Clare');
INSERT INTO `quotations` VALUES (23, 'Under the cherry &#8212;\r\nblossom soup,\r\nblossom salad', 'Matsuo', 'Basho');
INSERT INTO `quotations` VALUES (24, 'No spring, nor summer beauty hath such grace,\r\nAs I have seen in one autumnal face', 'John', 'Donne');
INSERT INTO `quotations` VALUES (25, 'Sweet lovers love the spring.', 'William', 'Shakespeare');
INSERT INTO `quotations` VALUES (26, 'O, Wind,\r\nIf Winter comes, can Spring be far behind?', 'Percy Bysshe', 'Shelley');
INSERT INTO `quotations` VALUES (27, 'In the spring a young man''s fancy lightly turns to thoughts of love', 'Alfred, Lord', 'Tennyson');
INSERT INTO `quotations` VALUES (28, 'It is not spring until you can plant your foot on twelve daisies.', '', 'Proverb');
INSERT INTO `quotations` VALUES (29, 'The way to ensure summer in England is to have it framed and glazed in a comfortable room.', 'Horace', 'Walpole');
INSERT INTO `quotations` VALUES (30, '&#8217;Tis the last rose of summer\r\nLeft blooming alone\r\nAll her lovely companions\r\nAre faded and gone', 'Thomas', 'Moore');
INSERT INTO `quotations` VALUES (31, 'Shall I compare thee to a summer''s day?\r\nThou art more lovely and temperate', '', 'Shakespeare');
INSERT INTO `quotations` VALUES (32, 'Now is the winter of our discontent\r\nMade glorious summer by this sun of York', '', 'Shakespeare');
INSERT INTO `quotations` VALUES (33, 'Blow, blow, thou winter wind,\r\nThou art not so unkind\r\nAs man''s ingratitude', 'W', 'Shakespeare');
INSERT INTO `quotations` VALUES (34, 'My age is as a lusty winter, frosty, but kindly.', 'William', 'Shakespeare');
INSERT INTO `quotations` VALUES (35, 'The first fall of snow is not only an event, but it is a magical event. You go to bed in one kind of world and wake up to find yourself in another quite different...', 'JB', 'Priestley');
INSERT INTO `quotations` VALUES (36, 'Therefore all seasons shall be sweet to thee.', 'Samuel Taylor', 'Coleridge');
INSERT INTO `quotations` VALUES (37, 'The frost performs its secret ministry,\r\nUnhelped by any wind', 'Samuel Taylor', 'Coleridge');
INSERT INTO `quotations` VALUES (38, 'And then my heart with pleasure fills,\r\nAnd dances with the daffodills', 'William', 'Wordsworth');
INSERT INTO `quotations` VALUES (39, 'Oh, my Luve''s like a red, red rose\r\nThat''s newly sprung in June', 'Robert', 'Burns');
INSERT INTO `quotations` VALUES (40, 'Season of mists and mellow fruitfulness,\r\nClose bosom-friend of the maturing sun', 'John', 'Keats');
INSERT INTO `quotations` VALUES (41, 'The coming musk rose, full of dewy wine,\r\nThe murmurous haunt of flies on summer eves', 'John', 'Keats');
INSERT INTO `quotations` VALUES (42, 'Snowy, Flowy, Blowy,\r\nShowery, Flowery, Bowery,\r\nHoppy, Croppy, Droppy,\r\nBreezy, Sneezy, Freezy', 'George', 'Ellis');
INSERT INTO `quotations` VALUES (43, 'Mais o&#249; sont les neiges d''antan? (But where are the snows of yesteryear?)', 'Fran&#231;ois', 'Villon');
INSERT INTO `quotations` VALUES (44, 'Summer time an'' the livin'' is easy,\r\nFish are jumpin'' and the cotton is high', 'Heyward &amp;', 'Gershwin');
INSERT INTO `quotations` VALUES (45, 'I never think of the future. It comes soon enough.', 'Albert', 'Einstein');
INSERT INTO `quotations` VALUES (46, 'The English never smash in a face. They merely refrain from asking it to dinner.', 'Margaret', 'Halsey');
INSERT INTO `quotations` VALUES (47, 'Once the toothpaste is out of the tube, it is awfully hard to get back in.', 'HR', 'Haldeman');
INSERT INTO `quotations` VALUES (48, 'Le sens commun est fort rare. (Common sense is not so common.)', '', 'Voltaire');
INSERT INTO `quotations` VALUES (49, 'I hate television. I hate it as much as peanuts. But I can''t stop eating peanuts.', 'Orson', 'Welles');
INSERT INTO `quotations` VALUES (50, 'I always say, keep a diary and some day it''ll keep you.', 'Mae', 'West');
