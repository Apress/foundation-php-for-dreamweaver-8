<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_POST['quote_id'])) && ($_POST['quote_id'] != "")) {
  $deleteSQL = sprintf("DELETE FROM quotations WHERE quote_id=%s",
                       GetSQLValueString($_POST['quote_id'], "int"));

  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $Result1 = mysql_query($deleteSQL, $seasonAdmin) or die(mysql_error());

  $deleteGoTo = "quote_list_2tab.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_listAuthors = "SELECT authors.author_id, CONCAT(authors.first_name,' ', authors.family_name) AS author FROM authors ORDER BY authors.family_name, authors.first_name";
$listAuthors = mysql_query($query_listAuthors, $seasonAdmin) or die(mysql_error());
$row_listAuthors = mysql_fetch_assoc($listAuthors);
$totalRows_listAuthors = mysql_num_rows($listAuthors);

$colname_getQuote = "-1";
if (isset($_GET['quote_id'])) {
  $colname_getQuote = (get_magic_quotes_gpc()) ? $_GET['quote_id'] : addslashes($_GET['quote_id']);
}
mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_getQuote = sprintf("SELECT * FROM quotations WHERE quote_id = %s", GetSQLValueString($colname_getQuote, "int"));
$getQuote = mysql_query($query_getQuote, $seasonAdmin) or die(mysql_error());
$row_getQuote = mysql_fetch_assoc($getQuote);
$totalRows_getQuote = mysql_num_rows($getQuote);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Delete quotation - two table version</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>
<h1>Delete quotation - 2 tables </h1>
<p class="warning">Please confirm that you want to delete the following quotation. This operation cannot be undone. </p>
<form id="deleteQuote" name="deleteQuote" method="POST">
  <p>
    <label for="quotation">Quotation:</label>
    <br />
    <textarea name="quotation" cols="80" rows="6" id="quotation"><?php echo $row_getQuote['quotation']; ?></textarea>
  </p>
  <p>
    <label for="author_id">Author:</label>
    <br />
    <select name="author_id" id="author_id">
        <option value="" <?php if (!(strcmp("", $row_getQuote['author_id']))) {echo "selected=\"selected\"";} ?>>Not registered</option>
        <?php
do {  
?>
        <option value="<?php echo $row_listAuthors['author_id']?>"<?php if (!(strcmp($row_listAuthors['author_id'], $row_getQuote['author_id']))) {echo "selected=\"selected\"";} ?>><?php echo $row_listAuthors['author']?></option>
        <?php
} while ($row_listAuthors = mysql_fetch_assoc($listAuthors));
  $rows = mysql_num_rows($listAuthors);
  if($rows > 0) {
      mysql_data_seek($listAuthors, 0);
	  $row_listAuthors = mysql_fetch_assoc($listAuthors);
  }
?>
        </select>
    <input name="quote_id" type="hidden" id="quote_id" value="<?php echo $row_getQuote['quote_id']; ?>" />
  </p>
  <p>
    <input name="delete" type="submit" id="delete" value="Delete quotation" />
  </p>
  
  
</form>
<p><a href="quote_list_2tab.php">List quotations</a> </p>
</body>
</html>
<?php
mysql_free_result($listAuthors);

mysql_free_result($getQuote);
?>