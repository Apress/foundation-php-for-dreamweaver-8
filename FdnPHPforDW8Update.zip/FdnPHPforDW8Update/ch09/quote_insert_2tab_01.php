<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Insert new quotation - two table version</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>
<h1>Insert new quotation - 2 tables </h1>
<form id="insertQuote" name="insertQuote" method="post" action="">
  <p>
    <label for="quotation">Quotation:</label>
    <br />
    <textarea name="quotation" cols="80" rows="6" id="quotation"></textarea>
  </p>
  <p>
    <label for="author_id">Author:</label>
    <br />
    <select name="author_id" id="author_id">
    </select>
  </p>
  <p>
    <input name="insert" type="submit" id="insert" value="Insert quotation" />
  </p>
</form>
<p><a href="quote_list_2tab.php">List quotations</a> </p>
</body>
</html>