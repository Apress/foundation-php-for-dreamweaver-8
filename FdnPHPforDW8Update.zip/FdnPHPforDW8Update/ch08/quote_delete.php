<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

if ((isset($_POST['quote_id'])) && ($_POST['quote_id'] != "")) {
  $deleteSQL = sprintf("DELETE FROM quotations WHERE quote_id=%s",
                       GetSQLValueString($_POST['quote_id'], "int"));

  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $Result1 = mysql_query($deleteSQL, $seasonAdmin) or die(mysql_error());

  $deleteGoTo = "quote_list.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $deleteGoTo));
}

$colname_getQuote = "-1";
if (isset($_GET['quote_id'])) {
  $colname_getQuote = (get_magic_quotes_gpc()) ? $_GET['quote_id'] : addslashes($_GET['quote_id']);
}
mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_getQuote = sprintf("SELECT * FROM quotations WHERE quote_id = %s", GetSQLValueString($colname_getQuote, "int"));
$getQuote = mysql_query($query_getQuote, $seasonAdmin) or die(mysql_error());
$row_getQuote = mysql_fetch_assoc($getQuote);
$totalRows_getQuote = mysql_num_rows($getQuote);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update quotation</title>
</head>

<body>
<h1>Update quotation </h1>
<p>You are about to delete the following quotation from the database. This operation cannot be undone. </p>
<form method="post" name="form1">
    <table align="center">
        <tr valign="baseline">
            <td nowrap align="right">First name:</td>
            <td><input type="text" name="first_name" value="<?php echo $row_getQuote['first_name']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
            <td nowrap align="right">Family name:</td>
            <td><input type="text" name="family_name" value="<?php echo $row_getQuote['family_name']; ?>" size="32"></td>
        </tr>
        <tr valign="baseline">
            <td nowrap align="right" valign="top">Quotation:</td>
            <td><textarea name="quotation" cols="50" rows="5"><?php echo $row_getQuote['quotation']; ?></textarea>
            </td>
        </tr>
        <tr valign="baseline">
            <td nowrap align="right">&nbsp;</td>
            <td><input type="submit" value="Confirm deletion"></td>
        </tr>
    </table>
    
    <input type="hidden" name="quote_id" value="<?php echo $row_getQuote['quote_id']; ?>">
</form>
<p>&nbsp;</p>
</body>
</html>
<?php
mysql_free_result($getQuote);
?>
