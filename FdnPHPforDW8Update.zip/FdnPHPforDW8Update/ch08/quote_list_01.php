<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_quoteList = "SELECT * FROM quotations ORDER BY quotations.family_name, quotations.first_name, quotations.quotation";
$quoteList = mysql_query($query_quoteList, $seasonAdmin) or die(mysql_error());
$row_quoteList = mysql_fetch_assoc($quoteList);
$totalRows_quoteList = mysql_num_rows($quoteList);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>List all quotations</title>
</head>

<body>
<h1>Contents of quotations table</h1>
<table width="700" cellpadding="4">
  <tr>
    <th scope="col">Name</th>
    <th scope="col">Quotation</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <tr>
    <td><?php echo $row_quoteList['first_name']; ?> <?php echo $row_quoteList['family_name']; ?></td>
    <td><?php echo $row_quoteList['quotation']; ?></td>
    <td><a href="quote_update.php?quote_id=<?php echo $row_quoteList['quote_id']; ?>">EDIT</a></td>
    <td><a href="quote_delete.php?quote_id=<?php echo $row_quoteList['quote_id']; ?>">DELETE</a></td>
  </tr>
</table>
<p>&nbsp; </p>
</body>
</html>
<?php
mysql_free_result($quoteList);
?>
