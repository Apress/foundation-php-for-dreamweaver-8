<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_getArticles = "SELECT article_id, title, created, image, caption FROM blog ORDER BY created DESC";
$getArticles = mysql_query($query_getArticles, $seasonAdmin) or die(mysql_error());
$row_getArticles = mysql_fetch_assoc($getArticles);
$totalRows_getArticles = mysql_num_rows($getArticles);
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>List blog entries</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>List blog entries</h1>
<table width="750" id="striped">
  <tr>
    <th scope="col">Date</th>
    <th scope="col">Title</th>
    <th scope="col">Image</th>
    <th scope="col">Caption</th>
    <th scope="col">&nbsp;</th>
    <th scope="col">&nbsp;</th>
  </tr>
  <?php do { ?>
      <tr>
          <td><?php echo $row_getArticles['created']; ?></td>
          <td><?php echo $row_getArticles['title']; ?></td>
          <td><?php echo $row_getArticles['image']; ?></td>
          <td><?php echo $row_getArticles['caption']; ?></td>
          <td><a href="blog_update.php?article_id=<?php echo $row_getArticles['article_id']; ?>">EDIT</a></td>
          <td><a href="blog_delete.php?article_id=<?php echo $row_getArticles['article_id']; ?>">DELETE</a></td>
      </tr>
      <?php } while ($row_getArticles = mysql_fetch_assoc($getArticles)); ?>
</table>
<h1>&nbsp; </h1>
</body>
</html>
<?php
mysql_free_result($getArticles);
?>