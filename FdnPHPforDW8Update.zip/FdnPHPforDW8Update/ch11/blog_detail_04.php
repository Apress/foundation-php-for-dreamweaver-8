<?php require_once('Connections/seasonQuery.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$var1_getArticle = "-1";
if (isset($_GET['article_id'])) {
  $var1_getArticle = (get_magic_quotes_gpc()) ? $_GET['article_id'] : addslashes($_GET['article_id']);
}
mysql_select_db($database_seasonQuery, $seasonQuery);
$query_getArticle = sprintf("SELECT blog.article_id, blog.title, blog.article, DATE_FORMAT(blog.created, '%%b %%e, %%Y') AS theDate, DATE_FORMAT(blog.created, '%%l.%%i.%%p on %%b %%e, %%Y') AS latest, blog.updated, blog.created, blog.image, blog.caption FROM blog WHERE blog.article_id = %s", GetSQLValueString($var1_getArticle, "int"));
$getArticle = mysql_query($query_getArticle, $seasonQuery) or die(mysql_error());
$row_getArticle = mysql_fetch_assoc($getArticle);
$totalRows_getArticle = mysql_num_rows($getArticle);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons</title>
<?php include('style_rules.php'); ?>
</head>

<body>
<div id="wrapper">
  <div id="titlebar"><img src="images_common/bluebells_top.jpg" alt="East-West Seasons" width="738" height="122" /></div>
  <div id="maincontent">
    <div id="nav">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="news.php">News</a></li>
        <li><a href="blog.php">Blog</a></li>
        <li><a href="gallery.php">Gallery</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </div>
    <h2><?php echo $row_getArticle['title']; ?></h2>
    <p><strong><?php echo $row_getArticle['theDate']; ?>:</strong>
	<?php $text = splitText($row_getArticle['article']); 
	echo nl2br($text[0]); ?>
	<!-- image code goes here -->
	<img src="images_blog/<?php echo $row_getArticle['image']; ?>" alt="<?php echo $row_getArticle['caption']; ?>" class="floatRight" /><?php echo nl2br($text[1]); ?>	</p>
    <?php if ($row_getArticle['updated'] != $row_getArticle['created']) { ?>
	<p>Last updated: <?php echo $row_getArticle['latest']; ?></p>
	<?php } ?>
    <p id="backlink"><a href="<?php
	// find out if the visitor was referred from a different domain
	// also check if server variables are supported (additional check not shown in book)
	if (isset($_SERVER['HTTP_REFERER']) && isset($_SERVER['HTTP_HOST'])) {
	  $url = parse_url($_SERVER['HTTP_REFERER']);
	  if ($url['host'] == $_SERVER['HTTP_HOST']) {
	    // if same domain, use referring URL
		echo $_SERVER['HTTP_REFERER'];
		}
	  else {
	    // otherwise send to main page
	    echo 'blog.php';
		}
	  } ?>">Back to the blog</a> </p>
  </div>
  <div id="footer"><?php include('copyright.php'); ?></div>
</div>
</body>
</html>
<?php
mysql_free_result($getArticle);

function splitText($text, $number=4) {
  // regular expression to find typical sentence endings
  $pattern = '/([.?!]["\']?)\s/';
  // use regex to insert break indicator
  $text = preg_replace($pattern, '$1bRE@kH3re', $text);
  // use break indicator to create array of sentences
  $sentences = explode('bRE@kH3re', $text);
  // check relative length of array and requested number
  $howMany = count($sentences);
  $number = $howMany >= $number ? $number : $howMany;
  // rebuild extract and return as single string
  $remainder = array_splice($sentences, $number);
  $result = array();
  $result[0] = implode(' ', $sentences);
  $result[1] = implode(' ', $remainder);
  return $result;
  }
?>
