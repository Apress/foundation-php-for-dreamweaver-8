// JavaScript Document
function showImage(elem) {
	if(!document.getElementById) {
		return false;
	} else {
		var bigPic = elem.getAttribute('href');
		var newCaption = elem.firstChild.getAttribute('alt');
		document.getElementById('mainpic').firstChild.setAttribute('src',bigPic);
		var theCaption = document.getElementById('picCaption');
		theCaption.firstChild.nodeValue = newCaption;
	}
}