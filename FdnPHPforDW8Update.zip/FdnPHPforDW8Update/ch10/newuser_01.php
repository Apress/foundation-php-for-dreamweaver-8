<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Register new user</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Register new user </h1>
<form id="newUser" name="newUser" method="POST">
  <p>
    <label for="first_name">First name:</label>
    <br />
    <input type="text" name="first_name" id="first_name" />
  </p>
  <p>
    <label for="family_name">Family name:</label>
    <br />
    <input type="text" name="family_name" id="family_name" />
  </p>
  <p>
    <label for="username">Username:<br />
    </label>
    <input type="text" name="username" id="username" />
  </p>
  <p>
    <label for="pwd">Password:</label>
    <br />
    <input type="password" name="pwd" id="pwd" />
  </p>
  <p>
    <label for="conf_pwd">Confirm password:</label>
    <br />
    <input type="password" name="conf_pwd" id="conf_pwd" />
  </p>
  <p>
    <label for="email">Email:</label>
    <br />
    <input name="email" type="text" class="mediumbox" id="email" />
  </p>
  <p><span class="radioLabel">Administrator: 
    </span>
    <input name="admin_priv" type="radio" value="y" id="administrator" />
    <label for="administrator">Yes</label>
    <input name="admin_priv" type="radio" id="not_admin" value="n" checked="checked" />
    <label for="not_admin">No</label>
  </p>
  <p>
    <input name="register" type="submit" id="register" value="Register new user" />
  </p>
  
  
</form>
</body>
</html>
