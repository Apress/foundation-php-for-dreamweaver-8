<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$error = array();
// Validate form input
$MM_flag="MM_insert";
if (isset($_POST[$MM_flag])) {
  // Check name
  if (empty($_POST['first_name']) || empty($_POST['family_name'])) {
    $error['name'] = 'Please enter both first name and family name';
	}
  // set a flag that assumes the password is OK
  $pwdOK = true;
  // trim leading and trailing white space
  $_POST['pwd'] = trim($_POST['pwd']);
  // if less than 6 characters, create alert and set flag to false
  if (strlen($_POST['pwd']) < 6) {
    $error['pwd_length'] = 'Your password must be at least 6 characters';
    $pwdOK = false;
    }
  // if no match create alert, and set flag to false
  if ($_POST['pwd'] != trim($_POST['conf_pwd'])) {
    $error['pwd'] = 'Your passwords don\'t match';
    $pwdOK = false;
    }
  // if password OK, encrypt it
  if ($pwdOK) {
    $_POST['pwd'] = sha1($_POST['pwd']);
    }
  // check for valid email address
  $pattern = '/^[^@]+@[^\s\r\n\'";,@%]+$/';
  if (!preg_match($pattern, trim($_POST['email']))) {
    $error['email'] = 'Please enter a valid email address';
    }  
  // check username
  $_POST['username'] = trim($_POST['username']);
  $loginUsername = $_POST['username'];
  if (strlen($loginUsername) < 6) {
    $error['length'] = 'Please select a username that contains at least 6 characters';
    }

  $LoginRS__query = sprintf("SELECT username FROM users WHERE username=%s", GetSQLValueString($loginUsername, "text"));
  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $LoginRS=mysql_query($LoginRS__query, $seasonAdmin) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);

  //if there is a row in the database, the username was found - can not add the requested username
  if($loginFoundUser){
    $error['username'] = "loginUsername is already in use. Please choose a different username.";
  }
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

if (!$error) {
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "newUser")) {
  $insertSQL = sprintf("INSERT INTO users (username, pwd, first_name, family_name, email, admin_priv) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['pwd'], "text"),
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['family_name'], "text"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['admin_priv'], "text"));

  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $Result1 = mysql_query($insertSQL, $seasonAdmin) or die(mysql_error());
}
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Register new user</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Register new user </h1>
<?php
if ($error) {
  echo '<ul>';
  foreach ($error as $alert) {
    echo "<li class='warning'>$alert</li>\n";
    }
  echo '</ul>';
  }
?>
<form action="<?php echo $editFormAction; ?>" id="newUser" name="newUser" method="POST">
  <p>
    <label for="first_name">First name:</label>
    <br />
    <input type="text" name="first_name" id="first_name" />
  </p>
  <p>
    <label for="family_name">Family name:</label>
    <br />
    <input type="text" name="family_name" id="family_name" />
  </p>
  <p>
    <label for="username">Username:<br />
    </label>
    <input type="text" name="username" id="username" />
  </p>
  <p>
    <label for="pwd">Password:</label>
    <br />
    <input type="password" name="pwd" id="pwd" />
  </p>
  <p>
    <label for="conf_pwd">Confirm password:</label>
    <br />
    <input type="password" name="conf_pwd" id="conf_pwd" />
  </p>
  <p>
    <label for="email">Email:</label>
    <br />
    <input name="email" type="text" class="mediumbox" id="email" />
  </p>
  <p><span class="radioLabel">Administrator: 
    </span>
    <input name="admin_priv" type="radio" value="y" id="administrator" />
    <label for="administrator">Yes</label>
    <input name="admin_priv" type="radio" id="not_admin" value="n" checked="checked" />
    <label for="not_admin">No</label>
  </p>
  <p>
    <input name="register" type="submit" id="register" value="Register new user" />
  </p>
  
  
  <input type="hidden" name="MM_insert" value="newUser">
</form>
</body>
</html>
