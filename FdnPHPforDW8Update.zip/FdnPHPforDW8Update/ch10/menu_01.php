<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>East-West Seasons Admin Area</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>East-West Seasons Admin</h1>
<p><a href="author_insert.php">Add new author</a></p>
<p><a href="quote_insert_2tab.php">Add new quotation</a></p>
<p><a href="quote_list_2tab.php">List and update quotations</a></p>
<p><a href="newuser.php">Register new user</a></p>
</body>
</html>
