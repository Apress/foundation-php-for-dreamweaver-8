<?php require_once('../Connections/seasonAdmin.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}



$colname_getUser = "-1";
if (isset($_GET['user_id'])) {
  $colname_getUser = (get_magic_quotes_gpc()) ? $_GET['user_id'] : addslashes($_GET['user_id']);
}
mysql_select_db($database_seasonAdmin, $seasonAdmin);
$query_getUser = sprintf("SELECT * FROM users WHERE user_id = %s", GetSQLValueString($colname_getUser, "int"));
$getUser = mysql_query($query_getUser, $seasonAdmin) or die(mysql_error());
$row_getUser = mysql_fetch_assoc($getUser);
$totalRows_getUser = mysql_num_rows($getUser);

$error = array();
// Validate form input
$MM_flag="MM_update";
if (isset($_POST[$MM_flag])) {
  // Check name
  if (empty($_POST['first_name']) || empty($_POST['family_name'])) {
    $error['name'] = 'Please enter both first name and family name';
	}
  // set a flag that assumes the password is OK
  $pwdOK = true;
  // trim leading and trailing white space
  $_POST['pwd'] = trim($_POST['pwd']);
  // if password field is empty, use existing password
  if (empty($_POST['pwd'])) {
    $_POST['pwd'] = $row_getUser['pwd'];
	}
  // otherwise, conduct normal checks
  else {
    // if less than 6 characters, create alert and set flag to false
    if (strlen($_POST['pwd']) < 6) {
      $error['pwd_length'] = 'Your password must be at least 6 characters';
      $pwdOK = false;
      }
    // if no match create alert, and set flag to false
    if ($_POST['pwd'] != trim($_POST['conf_pwd'])) {
      $error['pwd'] = 'Your passwords don\'t match';
      $pwdOK = false;
      }
    // if password OK, encrypt it
    if ($pwdOK) {
      $_POST['pwd'] = sha1($_POST['pwd']);
      }
	}
  // check for valid email address
  $pattern = '/^[^@]+@[^\s\r\n\'";,@%]+$/';
  if (!preg_match($pattern, trim($_POST['email']))) {
    $error['email'] = 'Please enter a valid email address';
    }  
  // check username
  $_POST['username'] = trim($_POST['username']);
  $loginUsername = $_POST['username'];
  if (strlen($loginUsername) < 6) {
    $error['length'] = 'Please select a username that contains at least 6 characters';
    }

  $LoginRS__query = sprintf("SELECT username FROM users WHERE username=%s AND user_id != %s", GetSQLValueString($loginUsername, "text"), GetSQLValueString($_POST['user_id'], "int"));
  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $LoginRS=mysql_query($LoginRS__query, $seasonAdmin) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);

  //if there is a row in the database, the username was found - can not add the requested username
  if($loginFoundUser){
    $error['username'] = "loginUsername is already in use. Please choose a different username.";
  }
}

if (!$error) {
if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "updateUser")) {
  $updateSQL = sprintf("UPDATE users SET username=%s, pwd=%s, first_name=%s, family_name=%s, email=%s, admin_priv=%s WHERE user_id=%s",
                       GetSQLValueString($_POST['username'], "text"),
                       GetSQLValueString($_POST['pwd'], "text"),
                       GetSQLValueString($_POST['first_name'], "text"),
                       GetSQLValueString($_POST['family_name'], "text"),
                       GetSQLValueString($_POST['email'], "text"),
                       GetSQLValueString($_POST['admin_priv'], "text"),
                       GetSQLValueString($_POST['user_id'], "int"));

  mysql_select_db($database_seasonAdmin, $seasonAdmin);
  $Result1 = mysql_query($updateSQL, $seasonAdmin) or die(mysql_error());

  $updateGoTo = "listusers.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $updateGoTo .= (strpos($updateGoTo, '?')) ? "&" : "?";
    $updateGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $updateGoTo));
}
}
?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Update user</title>
<link href="../styles/admin.css" rel="stylesheet" type="text/css" />
</head>

<body>
<h1>Update user </h1>
<?php
if ($error) {
  echo '<ul>';
  foreach ($error as $alert) {
    echo "<li class='warning'>$alert</li>\n";
    }
  echo '</ul>';
  // remove escape characters from POST array
if (get_magic_quotes_gpc()) {
  function stripslashes_deep($value) {
    $value = is_array($value) ? array_map('stripslashes_deep', $value) : stripslashes($value);
    return $value;
    }
  $_POST = array_map('stripslashes_deep', $_POST);
  }
  }
?>
<form action="<?php echo $editFormAction; ?>" id="updateUser" name="updateUser" method="POST">
  <p>
    <label for="first_name">First name:</label>
    <br />
    <input value="<?php if (isset($_POST['first_name'])) {
echo $_POST['first_name'];} else {
echo $row_getUser['first_name'];} ?>" type="text" name="first_name" id="first_name" />
  </p>
  <p>
    <label for="family_name">Family name:</label>
    <br />
    <input value="<?php if (isset($_POST['family_name'])) {
echo $_POST['family_name'];} else {
echo $row_getUser['family_name'];} ?>" type="text" name="family_name" id="family_name" />
  </p>
  <p>
    <label for="username">Username:<br />
    </label>
    <input value="<?php if (isset($_POST['username'])) {
echo $_POST['username'];} else {
echo $row_getUser['username'];} ?>" type="text" name="username" id="username" />
  </p>
  <p>
    <label for="pwd">Password (leave blank if no change):</label>
    <br />
    <input type="password" name="pwd" id="pwd" />
  </p>
  <p>
    <label for="conf_pwd">Confirm password:</label>
    <br />
    <input type="password" name="conf_pwd" id="conf_pwd" />
  </p>
  <p>
    <label for="email">Email:</label>
    <br />
    <input value="<?php if (isset($_POST['email'])) {
echo $_POST['email'];} else {
echo $row_getUser['email'];} ?>" name="email" type="text" class="mediumbox" id="email" />
  </p>
  <p><span class="radioLabel">Administrator: 
    </span>
    <input 
	<?php 
	if (!$_POST && !(strcmp($row_getUser['admin_priv'],"y"))) {
	  echo "checked=\"checked\"";
	  } 
	elseif ($_POST && !(strcmp($_POST['admin_priv'],"y"))) {
	  echo "checked=\"checked\"";
	  } 
	?>
	name="admin_priv" type="radio" value="y" id="administrator" />
    <label for="administrator">Yes</label>
    <input
	<?php
	if (!$_POST && !(strcmp($row_getUser['admin_priv'],"n"))) {
	  echo "checked=\"checked\"";
	  }
	elseif ($_POST && !(strcmp($_POST['admin_priv'],"n"))) {
	  echo "checked=\"checked\"";
	  }
	?>
	name="admin_priv" type="radio" id="not_admin" value="n" />
    <label for="not_admin">No</label>
  </p>
  <p>
      <input name="update" type="submit" id="update" value="Update user details" />
      <input name="user_id" type="hidden" id="user_id" value="<?php echo $row_getUser['user_id']; ?>" />
  </p>
  
  
  
  <input type="hidden" name="MM_update" value="updateUser">
</form>
</body>
</html>
<?php
mysql_free_result($getUser);
?>
